const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
  return {
    // 获取帖子列表
    postlist: await db.collection('teaching_collection').where({
      author_name: event.wechatNickName,
      author_avatar_url: event.wechatAvatarUrl
    })
      .field({
        _id: true,
        content: true,
        watch_count: true,
        update_time: true
      }).orderBy('update_time', 'desc').get()

  }
}