// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  return {
    // 获取帖子列表
    postlist: await db.collection('writing_collection').where({
      label:'爱情纪念日'
      }).field({
      _id: true,
      content: true,
      watch_count: true,
      title:true,
      update_time: true,
      image_url: true
    }).orderBy('update_time', 'desc').get()

  }
}